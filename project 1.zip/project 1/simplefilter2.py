#!/usr/bin/env python

"""
A filter that transforms input into lower case.
"""

import fileinput


def process(line):
    """For each line of input, transform it into lower case."""

    print(line[:-1].lower())


for line in fileinput.input():
    process(line)
