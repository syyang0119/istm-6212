#!/usr/bin/env python


"""
A filter that stops words.
"""
import fileinput

"""For each line of input, transform it into lower case."""

STOPS = ['a', 'about','the','after','of','to','all','am','an','and']

for line in fileinput.input():
    line = line.strip()
    if line in STOPS:
        continue
    print(line)
